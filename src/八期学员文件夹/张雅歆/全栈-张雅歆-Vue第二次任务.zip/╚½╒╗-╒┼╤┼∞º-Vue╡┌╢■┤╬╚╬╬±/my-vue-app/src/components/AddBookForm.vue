<template>
    <div class="add-book-form" v-if="!addingBookComplete">
        <button @click="startAddingBook" :disabled="addingBook">添加</button>
    </div>
    <div class="add-book-confirm" v-if="addingBook">
        <input type="text" v-model="newBook.title" placeholder="书名" required>
        <input type="number" v-model.number="newBook.price" placeholder="价格" required>
        <input type="number" v-model.number="newBook.quantity" min="1" placeholder="购买数量" required>
        <button @click="confirmAddBook">确认</button>
        <button @click="cancelAddBook">取消</button>
</div>
</template>

<script>
export default {
    props: {
        addingBook: {
            type: Boolean,
            default: false
        }
    },
    data() {
        return {
            newBook: {
                title: '',
                price: 0,
                quantity: 0
            }
        };
    },
    computed: {
        addingBookComplete() {

            return this.addingBook && this.newBook.title && this.newBook.price && this.newBook.quantity;
        }
    },
    methods: {
        startAddingBook() {

            this.addingBook = true;
        },
        confirmAddBook() {

            // 重置表单  
            this.newBook = {
                title: '',
                price: 0,
                quantity: 0
            };

            this.addingBook = false;
        },
        cancelAddBook() {
  
            this.newBook = {
                title: '',
                price: 0,
                quantity: 0
            };
            this.addingBook = false;
        }
    }
};  
</script>

<style scoped>
/* 在这里添加您的样式 */
</style>