<template>
    <div class="book-list">
        <div class="info-container">
            <div class="total-price">
                <h3>总价: ￥{{ totalBooksPrice.toFixed(2) }} &nbsp; 当前选中书籍：</h3>
            </div>
            <div class="selected-book" v-if="selectedBook">
                <h3>{{ selectedBook.title }}</h3>
            </div>
        </div>
        <table class="book-table">
            <thead>
                <tr>
                    <th>序号</th>
                    <th>书名</th>
                    <th>价格</th>
                    <th>购买数量</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <tr v-for="(book, index) in books" :key="index" :class="{ 'selected-row': selectedBook === book }"
                    @click="selectedBook = book">
                    <td>{{ index + 1 }}</td>
                    <td>{{ book.title }}</td>
                    <td>￥{{ book.price }}</td>
                    <button @click="decreaseQuantity(index)" :disabled="book.quantity === 1">-</button>
                    {{ book.quantity }}
                    <button @click="increaseQuantity(index)">+</button>
                    <td>
                        <button @click="removeBook(index)">删除</button>
                    </td>
                </tr>
            </tbody>
        </table>
        <div class="add-book-form" v-if="!addingBook && !addingBookComplete">
            <button @click="startAddingBook">添加</button>
        </div>
        <div class="add-book-confirm" v-if="addingBook">
            <input type="text" v-model="newBook.title" placeholder="书名" required>
            <input type="number" v-model.number="newBook.price" placeholder="价格" required>
            <input type="number" v-model.number="newBook.quantity" min="1" placeholder="购买数量" required>
            <button @click="confirmAddBook">确认</button>
            <button @click="cancelAddBook">取消</button>
        </div>
    </div>
</template>



<script>
export default {
    data() {
        return {
            books: [
                { id: 1, title: '书名1', price: 100, quantity: 1 },
                { id: 2, title: '书名2', price: 200, quantity: 2 },
            ],
            newBook: {
                title: '',
                price: 0,
                quantity: 1
            },
            selectedBook: null,
            addingBook: false,
            addingBookComplete: false
        };
    },
    computed: {
        totalBooksPrice() {
            return this.books.reduce((sum, book) => sum + book.price * book.quantity, 0);
        }
    },
    methods: {
        increaseQuantity(index) {
            this.books[index].quantity++;
            this.updateTotalPrice();
        },


        decreaseQuantity(index) {
            if (this.books[index].quantity > 1) {
                this.books[index].quantity--;
                this.updateTotalPrice();
            }
        },
        startAddingBook() {
            this.addingBook = true;
            this.addingBookComplete = false;
            this.newBook = { title: '', price: 0, quantity: 1 };
        },
        confirmAddBook() {
            if (this.newBook.title && this.newBook.price && this.newBook.quantity) {
                this.books.push({ ...this.newBook, id: Date.now() });
                this.addingBook = false;
                this.addingBookComplete = false;
                this.selectedBook = null;
                this.newBook = { title: '', price: 0, quantity: 1 };
            } else {
                alert('请填写完整的信息！');
            }
        },
        cancelAddBook() {
            this.addingBook = false;
            this.addingBookComplete = false;
            this.newBook = { title: '', price: 0, quantity: 1 };
        },
        removeBook(index) {
            this.books.splice(index, 1);
            if (this.selectedBook && this.selectedBook.id === this.books[index].id) {
                this.selectedBook = null;
            }
        }
    }

};
</script>


<style scoped>
.info-container {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 10px;
}



.book-list {
    list-style-type: none;
    padding: 0;
    margin: 0;
}


.selected-row {
    background-color: yellow;
}

.my-table {
    width: 100%;
    border-collapse: collapse;
}

.my-table th,
.my-table td {
    padding: 8px;
    border: 1px solid #ddd;
    text-align: left;
}

.add-button-container {
    margin-top: 10px;
    text-align: right;
}
</style>
