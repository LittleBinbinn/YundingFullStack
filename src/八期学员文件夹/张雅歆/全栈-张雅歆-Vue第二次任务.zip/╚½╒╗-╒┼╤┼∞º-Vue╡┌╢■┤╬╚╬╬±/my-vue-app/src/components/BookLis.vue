<template>
    <div class="book-list">
        <div class="info-container">
            <div class="total-price">
                <h3>总价: ￥{{ totalBooksPrice.toFixed(2) }} &nbsp; 当前选中书籍：</h3>
            </div>
            <div class="selected-book" v-if="selectedBook">
                <h3>{{ selectedBook.title }}</h3>
            </div>
        </div>
        <table class="book-table">
            <thead>
                <tr>
                    <th>序号</th>
                    <th>书名</th>
                    <th>价格</th>
                    <th>购买数量</th>
                    <th>操作</th>
                </tr>
            </thead>
            <tbody>
                <tr v-for="(book, index) in books" :key="book.id" :class="{ 'selected-row': selectedBook === book }"
                    @click="selectedBook = book">
                    <td>{{ index + 1 }}</td>
                    <td>{{ book.title }}</td>
                    <td>￥{{ book.price }}</td>
                    <button @click="decreaseQuantity(index)" :disabled="book.quantity === 1">-</button>
                    {{ book.quantity }}
                    <button @click="increaseQuantity(index)">+</button>
                    <td>
                        <button @click="removeBook(index)">删除</button>
                    </td>
                </tr>
            </tbody>
        </table>

        <add-book-form @add-book="handleAddBook" @cancel-add="handleCancelAdd"
            :adding-book="addingBook"></add-book-form>
    </div>
</template>

<script>
import AddBookForm from './AddBookForm.vue';

export default {
    components: {
        AddBookForm
    },
    data() {
        return {
            books: [

            ],
            selectedBook: null,
            addingBook: false,

        };
    },
    computed: {
        totalBooksPrice() {

        },
        methods: {
            increaseQuantity(index) {

            },
            decreaseQuantity(index) {

            },
            removeBook(index) {

            },
            handleAddBook(newBook) {

                this.books.push(newBook);
                this.addingBook = false;
                this.selectedBook = null;
            },
            handleCancelAdd() {

                this.addingBook = false;
            }
        }
    };  
</script>