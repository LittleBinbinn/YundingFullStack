<template>
    <slot name="title"></slot>
      <hr style="border: 2px solid black;">
      <slot name="content"></slot>
    <hr>
</template>

<script>
export default {
    
}
</script>

<style>

</style>