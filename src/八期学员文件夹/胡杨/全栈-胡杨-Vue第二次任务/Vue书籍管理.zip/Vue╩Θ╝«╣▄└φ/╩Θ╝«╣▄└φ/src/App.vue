<script>
import AppHeader from './components/AppHeader.vue';

export default {
  
  components: {
    AppHeader,
  },
  data() {
    return {
      flag: false,
      currentIndex: -1,
      count1: 1,
      newName: "",
      newPrice:0,
      books: [{
                bookName: "你好",
                count: 1,
                price:10
          },
        {
          bookName: "计算机",
          count: 1,
          price:5  
           }] 
    }
  },
  methods: {
    formatPrice(totalPrice) {
      return "￥"+totalPrice
    },
    decrement(index) {
      this.books[index].count--
    },
    increment(index) {
      this.books[index].count++
    },
    showFocus(index) {
      this.currentIndex=index
    },
    confirm() {
      if (this.newName === "") {
        alert("书名不能为空！")
      }
      else {
        if (this.newPrice > 0) {
          this.books.push({ bookName: this.newName, price: this.newPrice, count: this.count1 })
          this.flag = false
          this.newName = ""
          this.newPrice=0
        }
        else {
          alert("价格应当是正数")
        }
      }
    },
    change(index) {
      
      this.currentIndex = -1
      this.books.splice(index, 1)
        },
       
    
    exit() {
      this.newName = ""
      this.newPrice = 0
    }
  },
  computed: {
    totalPrice() {
      let price1 = 0
      for (let item of this.books) {
        price1 += item.price * item.count
      }
      return price1
    },
   
  }
}
</script>


<template>
  
  <strong>总价：{{ formatPrice(totalPrice) }}&nbsp;
     当前选中书籍：
     <template v-if="currentIndex!=-1">
      《{{ books[currentIndex].bookName }}》
    </template>
  </strong>
 
  <table>
    <thead>
      <tr>
        <th>序号</th>
        <th>书名</th>
        <th>价格</th>
        <th>购买数量</th>
        <th>操作</th>
      </tr>
    </thead>
    <tbody>
        <app-header :info="books" @dec="decrement" @inc="increment"  @focus="showFocus" @current="change"></app-header>
    <tr v-if="flag===true">
      <td>{{ this.books.length+1 }}</td>
      <td><input type="text" v-model="newName"></td>
      <td><input type="number" v-model="newPrice"></td>
      <td>
        <button>-</button>
       {{ count1 }}
        <button>+</button>
      </td>
      <td><button disabled>移除</button></td>
    </tr>
    </tbody>
 
  <div v-if="flag===false">
    <button @click="this.flag=true">添加</button>
  </div>
  <div v-else>
    <button @click="confirm" >确认</button>
    <button @click="this.flag=false,exit()">取消</button>
  </div>
  </table>
</template>


<style>
  th,td{
    border: 1px solid;
    padding-left: 60px;
    padding-right: 60px;
  }
  table{
    border-collapse: collapse;
  }
 
  .add{
    display: true;
  }
  thead{
    background-color: #aaa;
    opacity: 0.8;
  }


</style>