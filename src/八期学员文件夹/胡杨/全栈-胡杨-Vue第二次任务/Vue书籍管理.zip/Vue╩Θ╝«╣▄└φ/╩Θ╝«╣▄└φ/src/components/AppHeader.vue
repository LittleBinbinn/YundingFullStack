<script>
export default {
    data() {
        return {
            currentIndex:-1
        }
    },
    
    emits: ["del", "dec", "inc","focus","current"],
    props: {
        info: {
            type: Array,
            required: true,
        }
    },
    methods: {
    
    decrement(index) {
      this.$emit("dec",index)
    },
    increment(index) {
      this.$emit("inc",index)
        },
    del(index) {
        this.$emit("current", index)
            this.currentIndex=-1
        
       
        },
    focusflag(index) {
        this.currentIndex=index
        this.$emit("focus", index)
    }
  },
        
    }
</script>

<template>
    <tr v-for="(item,index) in info" @click="focusflag(index)" :class="{active:currentIndex===index}">
        <td>{{ index+1 }}</td>
        <td>《{{ item.bookName }}》</td>
        <td>￥{{ item.price }}</td>
        <td>
          <button @click="decrement(index)" :disabled="item.count<=0">-</button>
          {{ item.count }}
          <button @click="increment(index)">+</button>
        </td>
        <td>
          <button @click="del(index)">移除</button>
        </td>
    </tr>
</template>



<style>
 .active{
    background-color: red;
  }
  td{
    padding-left: 60px;
    text-align: center;
    padding-right: 60px;
  }

</style>