<template>
    <tr>
        <td>{{ count }}</td>
        <td @click="choosebook(count)">{{ bookname }}</td>
            <td>￥{{ price }}</td>
            <td><button @click="numdec(-1,count)" :disabled="count1 === 0">-</button>{{ count1 }}<button
                    @click="numinc(1,count)">+</button></td>
            <td><button @click="del(count)">移除</button></td>
    </tr>
</template>

<script>
export default {
    props:{
        count:Number,
        bookname:String,
        price:Number,
        buynum:Number,

    },
    data () {
        return {
            count1: this.buynum
        }
    },

    methods:{
        numdec(num,count){
            if(this.count1 > 0){
                this.count1--;
                this.$emit("numdec",num,count)
            }
        },
        numinc(num,count){
            this.count1++;
            this.$emit("numinc",num,count)
        },
        del(count){
            this.$emit("del",count)
        },
        choosebook(count) {
            this.$emit("choosebook", count)
        }
    }
}
</script>

<style>

</style>