

import { createApp } from 'vue/dist/vue.esm-bundler'

import App from './App.vue'
// const App = {
//     template:`<h2>{{title}}</h2>`,
//     data () {
//         return {
//             title:"hello"
//         }
//     }
// }

createApp(App).mount('#app')
