<template>
    <div class="list">
        <h2 class="sum">总价：￥{{sum}}</h2>
        <h2>当前选中书籍：{{ information[choose] ? information[choose].bookname : "" }}</h2><br />

    </div>
    <table class="booklist" border="1px" cellspacing="0" width="600px" height="30px" align="center">
        <thead>
            <tr>
                <th>序号</th>
                <th>书名</th>
                <th>价格</th>
                <th>购买数量</th>
                <th>操作</th>
            </tr>
        </thead>

        <tbody>
            <BookListVue v-for="(item,index) in information" :key="index+1" :bookname=item.bookname :price=item.price
                :count=index+1 :buynum=item.buynum @numsub="decress" @numinc="incress" @del="remove" @choosebook="choosebook" :class="{ ischoose: (index) === choose }">

            </BookListVue>
            <tr v-if="isaddshow">
                <td>{{ information.length + 1 }}</td>
                <td><input type="text" class="nameinput" v-model="newname"></td>
                <td><input type="text" class="priceinput" v-model="newprice"></td>
                <td><button @click="sub">-</button> {{ num }} <button @click="num++">+</button></td>
                <td><button disabled=true>移除</button></td>
            </tr>
        </tbody>
        <div id="addbook" v-if="!isaddshow"><button @click="add">添加</button></div>
        <div id="choice" v-if="isaddshow"><button @click="agreeadd">确认</button><button
                @click="function () { isaddshow = !isaddshow }">取消</button></div>
    </table>

    <BookList></BookList>
</template>


<script>
    import BookListVue from './components/BookList.vue'
    export default{
        components: {
            BookListVue
        },
        data () {
            return {
                name:"",
                isaddshow:false,
                information:[
                    { bookname: "《JavaScript高级程序设计》", price: 126, buynum: 0 },
                    { bookname: "《你不知道的JS(上卷)》", price: 78, buynum: 0 },
                    { bookname: "《你不知道的JS(中卷)》", price: 76, buynum: 0 },
                    { bookname: "《你不知道的JS(下卷)》", price: 64, buynum: 0 }
                ]
            }
        },
        methods:{
            decress(num,count){
                this.information[count-1].buynum += num
            },
            incress(num,count){
                this.information[count-1].buynum += num
            },
            remove(count){
                this.information.splice(count-1,1)
            },
            add(){
                this.isaddshow = !this.isaddshow
            },
            agreeadd() {
                if (this.newname == "") {
                    alert("书名不能为空！")
                } 
                else if(this.newprice == 0){
                    alert("价格不能为0!")
                }
                else {
                    this.isaddshow = !this.isaddshow;
                    this.bookinfo.push({ bookname: this.newname, price: this.newprice, buynum: 0 })
                }
            },
            choosebook(count) {
                this.choose = count - 1;
            }
        },

        computed:{
            sum(){
                let sum = 0
                for(let item of this.information){
                    sum  += item.price * item.buynum
                }
                return sum
            }
        }

    }
</script>

<style>
    .list {
        display: flex;
        justify-content: center;
        flex-wrap: wrap;
    }
    .ischoose {
        background-color: rgb(231, 192, 126);
    }
</style>