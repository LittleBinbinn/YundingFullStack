<template>
        <tr>
            <td>{{ +count }}</td>
            <td @click="choosebook(count)">{{ bookname }}</td>
            <td>￥{{ +price }}</td>
            <td><button @click="sub(-1,count)">-</button> {{ buynum2 }} <button @click="add(1,count)">+</button></td>
            <td><button @click="delbook(count)">移除</button></td>
        </tr>
</template>

<script>
export default {
    props: {
        count: Number,
        bookname: String,
        price: Number,
        buynum:Number
    },
    data () {
        return {
            buynum2:this.buynum
        }
    },
    methods: {
        sub(num,count) {
            if (this.buynum2 <= 0) {
                alert("已达到最小数量!");
            } else
            {
                this.buynum2--;
                this.$emit("subnum",num,count)
            }
        },
        add(num,count) {
            this.buynum2++;
            this.$emit("addnum",num,count)
        },
        delbook(count) {
            this.$emit("delbook",count)
        },
        choosebook(count) {
            this.$emit("choosebook",count)
        }
    }
    }
</script>

<style scoped>
    tr {
        width: 500px;
        display: inline-block;
        height: 44px;
    }
    td {
        width: 100px;
        text-align: center;
        border: 1px solid #000;
    }
</style>