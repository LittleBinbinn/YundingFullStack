<template>
  <div id="app">
    <div id="sumprice">总价:￥{{ sumprice }}  当前选中书籍:{{ bookinfo[choose]?bookinfo[choose].bookname:"书籍名称" }}</div>
    <table>
      <thead>
        <tr>
          <th>序号</th>
          <th>书名</th>
          <th>价格</th>
          <th>购买数量</th>
          <th>操作</th>
        </tr>
      </thead>
      
    <book-information-vue v-for="(item,index) in bookinfo" :count=index+1 :bookname=item.bookname :price=item.price :buynum="item.buynum" :key=index+1 @delbook="del" @choosebook="choosebook" :class="{ischoose:(index)===choose}" @subnum="subcount" @addnum="addcount">
    </book-information-vue>
    <tr v-if="isaddshow">
      <td>{{ bookinfo.length+1 }}</td>
      <td><input type="text" class="nameinput" v-model="newname"></td>
      <td><input type="text" class="priceinput" v-model="newprice"></td>
      <td><button @click="sub">-</button> {{ num }} <button @click="num++">+</button></td>
      <td><button disabled=true>移除</button></td>
    </tr>
    </table>
    <div id="addbook" v-if="!isaddshow"><button @click="addbook">添加</button></div>
    <div id="choice" v-if="isaddshow"><button @click="agreeadd">确认</button><button @click="function(){isaddshow=!isaddshow}">取消</button></div>
  </div>
</template>

<script>
import bookInformationVue from './components/book-information.vue'
export default {
  components: {
      bookInformationVue
  },
  data() {
    return {
      bookinfo: [
        { bookname: "《JavaScript高级程序设计》", price: 126 ,buynum:0},
        { bookname: "《你不知道的JS(上卷)》", price: 78 ,buynum:0},
        { bookname: "《你不知道的JS(中卷)》", price: 76 ,buynum:0},
        { bookname: "《你不知道的JS(下卷)》", price: 64 ,buynum:0}
      ],
      isaddshow: false,
      num: 0,
      newname:"",
      newprice: 0,
      choose: 0
    }
  },
  computed: {
    sumprice() {
      let sumprice = 0;
      for (let item of this.bookinfo) {
        sumprice += item.price * item.buynum;
      }
      return sumprice;
    }
  },
  methods: {
    del(count) {
      this.bookinfo.splice(count-1,1)
    },
    addbook() {
      this.isaddshow = !this.isaddshow;
    },
    sub() {
      if (this.num <= 0) {
          alert("已达到最小数量!");
      } else
      {
        this.num--;
      }
    },
    agreeadd() {
      if (this.newname == "" || this.newprice == 0) {
        alert("错误的信息！")
      } else {
        this.isaddshow = !this.isaddshow;
        this.bookinfo.push({ bookname: this.newname, price: this.newprice, buynum: 0 })
      }
    },
    choosebook(count) {
      this.choose = count - 1;
    },
    subcount(num,count) {
      this.bookinfo[count - 1].buynum += num;
    },
    addcount(num,count) {
      this.bookinfo[count - 1].buynum += num;
      
    }
  }
  }
</script>

<style scoped>
  *{
    margin: 0;
  }
  .ischoose {
    background-color: rgb(231, 192, 126);
  }
  tr {
    width: 500px;
    display: block;
    height: 64px;
  }
  th {
    width: 100px;
    text-align: center;
  }
  thead {
    background-color: rgb(221, 217, 217);
  }
  #sumprice {
    font-size: 20px;
    width: 500px;
    text-align: center;
  }
  td {
    width: 100px;
    text-align: center;
    border: 1px solid #000;
  }
  input {
    width: 100px;
  }
</style>